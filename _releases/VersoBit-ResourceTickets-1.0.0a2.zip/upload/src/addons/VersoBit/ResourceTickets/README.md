# XF-ResourceTickets
 Automatically creates/replies to tickets on new resource/resource update submissions respectively.
